"""Dashboard package for modular Streamlit apps."""
